﻿namespace ChessMaster2017.Engine.Enums
{
    public enum EnumColor
    {
        White,
        Black
    }
}
