﻿namespace ChessMaster2017.Engine.Enums
{
    public enum EnumType
    {
        Pawn,
        Rook,
        Bishop,
        Knight,
        Queen,
        King
    }
}
